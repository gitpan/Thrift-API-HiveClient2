Thrift-API-HiveClient2
======================

A very rough Perl to HiveServer2 API (as provided in Cloudera's Hadoop CDH4.2+)

Please read the in-file comments for HiveServer2 configuration details.

Distribution is generated using Dist::Zilla. To create the tarball for this distribution, 
run dzil build in the base directory.

(c) 2013 Booking.com & David Morel.

Some parts are (c) R.Scaffidi.

Hive Thrift interface files are (c) 2013 The Apache Software Foundation.
